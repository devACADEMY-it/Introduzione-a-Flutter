import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Welcome to Flutter',
      home: Scaffold(
          appBar: AppBar(
            title: const Text('Widget Layout App'),
          ),
          body: GridView.count(crossAxisCount: 3, children: [
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            )),
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            )),
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            )),
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            )),
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            )),
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            )),
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            )),
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            )),
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            )),
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            )),
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            )),
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            )),
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            )),
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            )),
            SizedBox(
                child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)]),
            ))
          ])),
    );
  }
}
