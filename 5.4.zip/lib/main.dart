import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Welcome to Flutter',
      home: Scaffold(
          appBar: AppBar(
            title: const Text('Widget Layout App'),
          ),
          body: _buildProfile()),
    );
  }

  Widget _buildProfile() {
    const urlImage =
        'https://img.huffingtonpost.com/asset/5ebd20bb2200003015828b63.jpeg?cache=Rx7jA0QeN9&ops=crop_9_249_1938_1774,scalefit_630_noupscale';

    return Stack(clipBehavior: Clip.none, children: [
      Container(height: 240, color: Colors.orange),
      Positioned(
          bottom: -60,
          left: 0,
          right: 0,
          child: Center(
              child: Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                image: const DecorationImage(
                    image: NetworkImage(urlImage), fit: BoxFit.cover)),
          )))
    ]);
  }
}
