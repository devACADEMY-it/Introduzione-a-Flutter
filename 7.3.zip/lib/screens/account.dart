import 'package:flutter/material.dart';
import 'package:my_app/screens/account/account_1.dart';
import 'package:my_app/screens/account/account_2.dart';
import 'package:my_app/screens/account/account_3.dart';

class UserAccount extends StatelessWidget {
  const UserAccount({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 60),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  height: 100,
                  width: 100,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('images/carmhack.jpeg'),
                      fit: BoxFit.cover
                    ),
                    shape: BoxShape.circle,
                  ),
                ),
                Column(
                  children: const [
                    Text('391', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
                    Text('post')
                  ],
                ),
                Column(
                  children: const [
                    Text('1954', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
                    Text('follower')
                  ],
                ),
                Column(
                  children: const [
                    Text('281', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
                    Text('following')
                  ],
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('carmhack', style: TextStyle(fontWeight: FontWeight.bold)),
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 5.0),
                    child: Text('Frontend Developer & Instructor'),
                  ),
                  Text('link', style: TextStyle(color: Colors.blue)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(2.0),
                      child: Container(
                        padding: const EdgeInsets.all(5.0),
                        child: const Center(
                          child: Text('Edit Profile'),
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(5),
                        )
                      ), 
                      
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(2.0),
                      child: Container(
                        padding: const EdgeInsets.all(5.0),
                        child: const Center(
                          child: Text('Ad Tools'),
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(5),
                        )
                      ), 
                      
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(2.0),
                      child: Container(
                        padding: const EdgeInsets.all(5.0),
                        child: const Center(
                          child: Text('Insights'),
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(5),
                        )
                      ), 
                      
                    ),
                  )
                ],
              )
            ),
            const TabBar(
              tabs: [
                Tab(icon: Icon(Icons.grid_3x3_outlined)),
                Tab(icon: Icon(Icons.video_call)),
                Tab(icon: Icon(Icons.person)),
              ]
            ),
            const Expanded(
              child: TabBarView(
                children: [
                  Account1(),
                  Account2(),
                  Account3(),
                ]
              ),
            ),
          ]
        )
      )
    );
  }
}