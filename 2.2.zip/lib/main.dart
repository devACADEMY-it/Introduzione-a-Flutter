import 'package:flutter/material.dart';

void main() {
  runApp(
      const MaterialApp(title: "La mia app", home: SafeArea(child: MyApp())));
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
        child: Column(children: const [
      Text('Testo 1'),
      Text('TEsto 2'),
    ]));
  }
}
