import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class Product {
  const Product({required this.name});

  final String name;
}

typedef CartChangedCallback = Function(Product product, bool inCart);

class ShoppingListItem extends StatelessWidget {
  ShoppingListItem(
      {required this.product,
      required this.inCart,
      required this.onCartChanged})
      : super(key: ObjectKey(product));

  final Product product;
  final bool inCart;
  final CartChangedCallback onCartChanged;

  Color _getColor(BuildContext context) {
    if (inCart) {
      return Colors.black54;
    } else {
      return Theme.of(context).primaryColor;
    }
  }

  TextStyle? _getTextStyle(BuildContext context) {
    if (!inCart) return null;

    return const TextStyle(
      color: Colors.black54,
      decoration: TextDecoration.lineThrough,
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
        onTap: () {
          onCartChanged(product, inCart);
        },
        leading: CircleAvatar(
            backgroundColor: _getColor(context), child: Text(product.name[0])),
        title: Text(product.name, style: _getTextStyle(context)));
  }
}

class ShoppingList extends StatefulWidget {
  const ShoppingList({required this.products, Key? key}) : super(key: key);

  final List<Product> products;

  @override
  _ShoppingListState createState() => _ShoppingListState();
}

class _ShoppingListState extends State<ShoppingList> {
  final _cart = <Product>{};

  void _handleCartChanged(Product product, bool inCart) {
    setState(() {
      if (inCart) {
        _cart.remove(product);
      } else {
        _cart.add(product);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        children: widget.products.map((Product product) {
          return ShoppingListItem(
            product: product,
            inCart: _cart.contains(product),
            onCartChanged: _handleCartChanged,
          );
        }).toList());
  }
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Welcome to Flutter',
      home: Scaffold(
          appBar: AppBar(
            title: const Text('Shopping List App'),
          ),
          body: const ShoppingList(products: [
            Product(name: 'Uova'),
            Product(name: 'Farina'),
            Product(name: 'Latte'),
            Product(name: 'Pane'),
            Product(name: 'Pasta'),
            Product(name: 'Pollo'),
            Product(name: 'Zucchine'),
            Product(name: 'Broccoli'),
          ])),
    );
  }
}
