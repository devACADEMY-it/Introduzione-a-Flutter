import 'package:flutter/material.dart';
import 'package:my_app/components/explore_grid.dart';

class UserSearch extends StatelessWidget {
  const UserSearch({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Container(
          padding: const EdgeInsets.all(8.0),
          color: Colors.grey[300],
          child: const TextField(
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderSide: BorderSide.none,
                borderRadius: BorderRadius.all(Radius.circular(30)),
              ),
              prefixIcon: Icon(Icons.search),
              hintText: 'Search'
            ),
          ),
        )
      ),
      body: Container(
        margin: const EdgeInsets.only(top: 8.0),
        child: const ExploreGrid(),
      ),
    );
  }
}