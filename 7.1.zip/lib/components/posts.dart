import 'package:flutter/material.dart';

class Post extends StatelessWidget {
  const Post({ required this.username, Key? key }) : super(key: key);

  final String username;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  // Profile image
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage('images/$username.jpeg'),
                        fit: BoxFit.cover
                      ),
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 10),
                  // Username
                  Text(username, style: const TextStyle(fontWeight: FontWeight.bold)),
                ]
              ),
              // Menu
              const Icon(Icons.more_vert),
            ]
          ),
        ),
        // Post image
        Container(
          height: 400,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('images/${username}_post.jpeg'),
              fit: BoxFit.cover
            )
          ),
        ),
        // Post buttons
        Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: const [
                  Icon(Icons.favorite_border_outlined),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 8.0),
                    child: Icon(Icons.chat_bubble_outline),
                  ),
                  Icon(Icons.share),
                ]
              ),
              const Icon(Icons.bookmark_border_outlined),
            ]
          )
        ),
        // Likes
        Padding(
          padding: const EdgeInsets.only(left: 12.0),
          child: Row(
            children: const [
              Text('Piace a '),
              Text('carmhack', style: TextStyle(fontWeight: FontWeight.bold)),
              Text(' e altri'),
            ]
          ),
        ),
        // Caption
        Padding(
          padding: const EdgeInsets.only(left: 12.0, top: 8.0),
          child: Row(
            children: [
              Text(username, style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(width: 5),
              const Text('Caption'),
            ],
          )
        ),
      ],
    );
  }
}