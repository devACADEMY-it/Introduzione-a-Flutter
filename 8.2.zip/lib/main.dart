import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';

Future<Pokemon> getPokemon() async {
  final response = await http
      .get(Uri.parse('https://pokeapi.co/api/v2/pokemon/bulbasaur'));

  if (response.statusCode == 200) {
    // If the server did return a 200 OK response,
    // then parse the JSON.
    return Pokemon.fromJSON(jsonDecode(response.body));
  } else {
    // If the server did not return a 200 OK response,
    // then throw an exception.
    throw Exception('Failed to load pokemon');
  }
}

class Pokemon {
  final int weight;
  final int height;
  final String name;
  final dynamic images;

  Pokemon({ required this.weight, required this.height, required this.name, required this.images });

  factory Pokemon.fromJSON(Map<String, dynamic> json) {
    return Pokemon(
      weight: json['weight'],
      height: json['height'],
      name: json['name'],
      images: json['sprites']
    );
  }
}

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({ Key? key }) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late Future<Pokemon> pokemonFuture;
  
  void makeRequest() {
    pokemonFuture = getPokemon();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pokemon App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Pokemon App'),
        ),
        body: Center(
          child: Column(
            children: [
              FutureBuilder<Pokemon>(
                future: pokemonFuture,
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    return Column(
                      children: [
                        Text(snapshot.data!.name),
                        Text('Altezza: ${snapshot.data!.height}, Peso: ${snapshot.data!.weight}'),
                        Image.network(snapshot.data!.images['front_default']),
                      ]
                    );
                  } else if (snapshot.hasError) {
                    return Text('Errore: ${snapshot.error}');
                  }

                  // By default, show a loading spinner.
                  return const CircularProgressIndicator();
                },
              ),
              ElevatedButton(
                onPressed: makeRequest,
                child: const Text('Get Pokemon')
              ),
            ],
          ),
        ),
      ),
    );
  }
}