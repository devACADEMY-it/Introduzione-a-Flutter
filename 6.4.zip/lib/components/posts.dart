import 'package:flutter/material.dart';

class Post extends StatelessWidget {
  const Post({ required this.username, Key? key }) : super(key: key);

  final String username;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  // Profile image
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.grey[400],
                      shape: BoxShape.circle,
                    ),
                  ),
                  SizedBox(width: 10),
                  // Username
                  Text(username, style: TextStyle(fontWeight: FontWeight.bold)),
                ]
              ),
              // Menu
              Icon(Icons.more_vert),
            ]
          ),
        ),
        // Post image
        Container(
          height: 400,
          color: Colors.grey[400],
        ),
        // Post buttons
        Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: const [
                  Icon(Icons.favorite_border_outlined),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 8.0),
                    child: Icon(Icons.chat_bubble_outline),
                  ),
                  Icon(Icons.share),
                ]
              ),
              const Icon(Icons.bookmark_border_outlined),
            ]
          )
        )
      ],
    );
  }
}