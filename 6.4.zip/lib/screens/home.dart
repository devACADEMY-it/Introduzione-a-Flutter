import 'package:flutter/material.dart';
import 'package:my_app/components/posts.dart';
import 'package:my_app/components/stories.dart';

class UserHome extends StatelessWidget {
  const UserHome({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Instagram', style: TextStyle(color: Colors.black)),
            Row(
              children: const [
                Icon(Icons.add),
                Padding(
                  padding: EdgeInsets.all(24.0),
                  child: Icon(Icons.favorite_border_outlined),
                ),
                Icon(Icons.share)
              ],
            )
          ],
        )
      ),
      body: Column(
        children: [
          // stories
          SizedBox(
            height: 120,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                Stories(username: 'fedez'),
                Stories(username: 'chiara_ferragni'),
                Stories(username: 'carmhack'),
                Stories(username: 'bobo_vieri'),
                Stories(username: 'gianluca'),
                Stories(username: 'piero'),
                Stories(username: 'gabriele'),
                Stories(username: 'giovanni'),
                Stories(username: 'andrea'),
              ],
            )
          ),
          // posts
          Post(username: 'fedez'),
        ],
      )
    );
  }
}