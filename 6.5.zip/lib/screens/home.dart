import 'package:flutter/material.dart';
import 'package:my_app/components/posts.dart';
import 'package:my_app/components/stories.dart';

class UserHome extends StatelessWidget {
  const UserHome({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Instagram', style: TextStyle(color: Colors.black)),
            Row(
              children: const [
                Icon(Icons.add),
                Padding(
                  padding: EdgeInsets.all(24.0),
                  child: Icon(Icons.favorite_border_outlined),
                ),
                Icon(Icons.share)
              ],
            )
          ],
        )
      ),
      body: ListView(
        children: [
          // stories
          SizedBox(
            height: 120,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                Stories(username: 'fedez'),
                Stories(username: 'the_jackal'),
                Stories(username: 'shooterhatesyou'),
                Stories(username: 'camihawke'),
                Stories(username: 'adrian_fartade'),
                Stories(username: 'sixnationsrugby'),
                Stories(username: 'mirimeo'),
                Stories(username: 'ventennipaperoni'),
                Stories(username: 'spotifyitaly'),
              ],
            )
          ),
          // posts
          Post(username: 'fedez'),
          Post(username: 'the_jackal'),
          Post(username: 'camihawke'),
          Post(username: 'sixnationsrugby'),
          Post(username: 'mirimeo'),
        ],
      )
    );
  }
}